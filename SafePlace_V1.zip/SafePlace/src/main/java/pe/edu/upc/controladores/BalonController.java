package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Balon;
import pe.edu.upc.entidades.Establecimiento;
import pe.edu.upc.service.IBalonService;
import pe.edu.upc.service.IEstablecimientoService;

@Named
@RequestScoped
public class BalonController {
	@Inject
	private IBalonService bService;

	@Inject
	private IEstablecimientoService eService;

	private Balon b;
	private Balon busqueda;
	List<Balon> listaBalones;

	List<Establecimiento> listaEstablecimientos;

	// constructor
	@PostConstruct
	public void init() {
		this.listaBalones = new ArrayList<Balon>();
		this.listaEstablecimientos = new ArrayList<Establecimiento>();
		this.b = new Balon();
		this.busqueda = new Balon();
		this.list();
		this.listEstablecimientos();
	}

	// m�todos
	
	public String updateBalon(Balon balon) {
		this.setB(balon);
		return "balon.xhtml";
	}

	public void save() {
		try {
			if (b.getIdBalon() == 0) {
				bService.insert(b);
			} else {
				bService.update(b);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller balon");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getTypeBalon().isEmpty()) {
				this.list();
			} else {
				listaBalones = bService.findBy(this.getBusqueda());
			}
		} catch (Exception e) {
			System.out.println("Error al buscar en el controller balon");
		}
	}

	public String newBalon() {
		this.setB(new Balon());
		this.listEstablecimientos();
		return "balon.xhtml";
	}

	public void list() {
		try {
			listaBalones = bService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller balon");
		}
	}

	public void listEstablecimientos() {
		try {
			listaEstablecimientos = eService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller establecimiento");
		}
	}

	public void delete(Balon e) {
		try {
			bService.delete(e.getIdBalon());
			this.list();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller balon");
		}
	}

	// getters and setters

	public Balon getB() {
		return b;
	}

	public void setB(Balon b) {
		this.b = b;
	}

	public List<Balon> getListaBalones() {
		return listaBalones;
	}

	public void setListaBalones(List<Balon> listaBalones) {
		this.listaBalones = listaBalones;
	}

	public List<Establecimiento> getListaEstablecimientos() {
		return listaEstablecimientos;
	}

	public void setListaEstablecimientos(List<Establecimiento> listaEstablecimientos) {
		this.listaEstablecimientos = listaEstablecimientos;
	}

	public Balon getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(Balon busqueda) {
		this.busqueda = busqueda;
	}

	
	
}
