package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import pe.edu.upc.dao.IUsuarioDao;
import pe.edu.upc.entidades.Usuario;

public class UsuarioDaoImpl implements IUsuarioDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Override
	public List<Usuario> listByUsernameYContrasenia(String username, String contrasenia) {
		List<Usuario> users = new ArrayList<>();
		TypedQuery<Usuario> query = em.createQuery("FROM Usuario u WHERE u.username LIKE ?1 AND u.contrasenia LIKE ?2",
				Usuario.class);
		query.setParameter(1, username);
		query.setParameter(2, contrasenia);
		users = query.getResultList();
		return users;
	}
}
