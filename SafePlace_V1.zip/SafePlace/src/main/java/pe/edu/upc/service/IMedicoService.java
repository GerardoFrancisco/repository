package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entidades.Medico;

public interface IMedicoService {

	public void insert(Medico m);

	public List<Medico> list();

	public void delete(int idMedico);

	List<Medico> findBy(Medico e);

	void update(Medico t);
	

}
