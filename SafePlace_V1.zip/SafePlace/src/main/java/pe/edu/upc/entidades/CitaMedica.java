package pe.edu.upc.entidades;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CitaMedica")
public class CitaMedica {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idCitaMedica;

	@ManyToOne
	@JoinColumn(name = "idReserva", nullable = false)
	private Reserva reserva;
	
	@ManyToOne
	@JoinColumn(name = "idMedico", nullable = false)
	private Medico medico;
	
	public CitaMedica() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CitaMedica(int idCitaMedica, Reserva reserva, Medico medico) {
		super();
		this.idCitaMedica = idCitaMedica;
		this.reserva = reserva;
		this.medico = medico;
	}

	public int getIdCitaMedica() {
		return idCitaMedica;
	}

	public void setIdCitaMedica(int idCitaMedica) {
		this.idCitaMedica = idCitaMedica;
	}

	public Reserva getReserva() {
		return reserva;
	}

	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idCitaMedica, medico, reserva);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CitaMedica other = (CitaMedica) obj;
		return idCitaMedica == other.idCitaMedica && Objects.equals(medico, other.medico)
				&& Objects.equals(reserva, other.reserva);
	}

	
	
}