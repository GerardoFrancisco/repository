package pe.edu.upc.entidades;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TipoPago")
public class TipoPago {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTipoPago;

	@Column(name = "namePago", nullable = false, length = 45)
	private String namePago;

	public TipoPago() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TipoPago(int idTipoPago, String namePago) {
		super();
		this.idTipoPago = idTipoPago;
		this.namePago = namePago;
	}

	public int getIdTipoPago() {
		return idTipoPago;
	}

	public void setIdTipoPago(int idTipoPago) {
		this.idTipoPago = idTipoPago;
	}

	public String getNamePago() {
		return namePago;
	}

	public void setNamePago(String namePago) {
		this.namePago = namePago;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idTipoPago, namePago);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoPago other = (TipoPago) obj;
		return idTipoPago == other.idTipoPago && Objects.equals(namePago, other.namePago);
	}

	
	
}
