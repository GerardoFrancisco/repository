package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IReservaDao;
import pe.edu.upc.entidades.Reserva;
import pe.edu.upc.service.IReservaService;

@Named
public class ReservaServiceImpl implements IReservaService {

	@Inject
	private IReservaDao rDao;

	@Override
	public void insert(Reserva e) {
		rDao.insert(e);
	}

	@Override
	public List<Reserva> list() {
		// TODO Auto-generated method stub
		return rDao.list();
	}

	@Override
	public void delete(int idReserva) {
		// TODO Auto-generated method stub
		rDao.delete(idReserva);
	}

	@Override
	public List<Reserva> findBy(Reserva e) {
		// TODO Auto-generated method stub
		return rDao.findBy(e);
	}

	@Override
	public void update(Reserva t) {
		rDao.update(t);
	}
}
