package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.ITipoPagoDao;
import pe.edu.upc.entidades.TipoPago;

public class TipoPagoDaoImpl implements ITipoPagoDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(TipoPago r) {
		try {
			em.persist(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar tipo pago");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TipoPago> list() {
		List<TipoPago> listaTipoPagos = new ArrayList<TipoPago>();

		try {
			Query jpql = em.createQuery("from TipoPago t");
			listaTipoPagos = (List<TipoPago>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar tipo pagos");
		}
		return listaTipoPagos;
	}

	@Transactional
	@Override
	public void delete(int idTipoPago) {
		try {
			TipoPago r = em.find(TipoPago.class, idTipoPago);
			em.remove(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TipoPago> findBy(TipoPago tipoPago) {
		List<TipoPago> listaTipoPagos = new ArrayList<TipoPago>();

		try {
			Query jpql = em.createQuery("from TipoPago t where t.namePago like ?1");
			jpql.setParameter(1, "%" + tipoPago.getNamePago() + "%");
			listaTipoPagos = (List<TipoPago>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar tipo pagos");
		}
		return listaTipoPagos;
	}
	
	@Transactional
	@Override
	public void update(TipoPago r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar tipo pago");
		}
	}
}
