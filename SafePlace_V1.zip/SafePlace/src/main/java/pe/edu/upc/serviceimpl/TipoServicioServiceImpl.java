package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.ITipoServicioDao;
import pe.edu.upc.entidades.TipoServicio;
import pe.edu.upc.service.ITipoServicioService;

@Named
public class TipoServicioServiceImpl implements ITipoServicioService {

	@Inject
	private ITipoServicioDao tDao;

	@Override
	public void insert(TipoServicio t) {
		tDao.insert(t);
	}

	@Override
	public List<TipoServicio> list() {
		// TODO Auto-generated method stub
		return tDao.list();
	}

	@Override
	public void delete(int idTipoServicio) {
		// TODO Auto-generated method stub
		tDao.delete(idTipoServicio);
	}

	@Override
	public List<TipoServicio> findBy(TipoServicio e) {
		// TODO Auto-generated method stub
		return tDao.findBy(e);
	}

	@Override
	public void update(TipoServicio t) {
		tDao.update(t);
	}
}
