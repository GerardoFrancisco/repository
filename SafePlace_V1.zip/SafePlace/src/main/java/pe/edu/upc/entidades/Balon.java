package pe.edu.upc.entidades;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Balon")
public class Balon {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idBalon;

	@Column(name = "typeBalon", nullable = false, length = 45)
	private String typeBalon;

	@Column(name = "capacidad", nullable = false, length = 45)
	private double capacidad;

	@Column(name = "peso", nullable = false, length = 45)
	private double peso;

	@Column(name = "precio", nullable = false, length = 45)
	private double precio;
	
	@ManyToOne
	@JoinColumn(name = "idEstablecimiento", nullable = false)
	private Establecimiento establecimiento;

	public Balon() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Balon(int idBalon, String typeBalon, double capacidad, double peso, double precio,
			Establecimiento establecimiento) {
		super();
		this.idBalon = idBalon;
		this.typeBalon = typeBalon;
		this.capacidad = capacidad;
		this.peso = peso;
		this.precio = precio;
		this.establecimiento = establecimiento;
	}

	public int getIdBalon() {
		return idBalon;
	}

	public void setIdBalon(int idBalon) {
		this.idBalon = idBalon;
	}

	public String getTypeBalon() {
		return typeBalon;
	}

	public void setTypeBalon(String typeBalon) {
		this.typeBalon = typeBalon;
	}

	public double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Establecimiento getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(Establecimiento establecimiento) {
		this.establecimiento = establecimiento;
	}

	@Override
	public int hashCode() {
		return Objects.hash(capacidad, establecimiento, idBalon, peso, precio, typeBalon);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Balon other = (Balon) obj;
		return Double.doubleToLongBits(capacidad) == Double.doubleToLongBits(other.capacidad)
				&& Objects.equals(establecimiento, other.establecimiento) && idBalon == other.idBalon
				&& Double.doubleToLongBits(peso) == Double.doubleToLongBits(other.peso)
				&& Double.doubleToLongBits(precio) == Double.doubleToLongBits(other.precio)
				&& Objects.equals(typeBalon, other.typeBalon);
	}

	
}
