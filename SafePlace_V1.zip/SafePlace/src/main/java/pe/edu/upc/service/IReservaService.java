package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entidades.Reserva;

public interface IReservaService {

	public void insert(Reserva r);

	public List<Reserva> list();

	public void delete(int idReserva);

	List<Reserva> findBy(Reserva e);

	void update(Reserva t);
}
