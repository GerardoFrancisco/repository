package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entidades.CitaMedica;

public interface ICitaMedicaService {

	public void insert(CitaMedica c);

	public List<CitaMedica> list();

	public void delete(int idCitaMedica);

	List<CitaMedica> findBy(CitaMedica c);

	void update(CitaMedica c);
}
