package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IMedicoDao;
import pe.edu.upc.entidades.Medico;
import pe.edu.upc.service.IMedicoService;

@Named
public class MedicoServiceImpl implements IMedicoService {

	@Inject
	private IMedicoDao pDao;

	@Override
	public void insert(Medico m) {
		pDao.insert(m);
	}

	@Override
	public List<Medico> list() {
		// TODO Auto-generated method stub
		return pDao.list();
	}

	@Override
	public void delete(int idMedico) {
		// TODO Auto-generated method stub
		pDao.delete(idMedico);
	}
	
	@Override
	public List<Medico> findBy(Medico e) {
		// TODO Auto-generated method stub
		return pDao.findBy(e);
	}

	@Override
	public void update(Medico t) {
		pDao.update(t);
	}

}
