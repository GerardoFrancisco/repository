package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.TipoPago;

public interface ITipoPagoDao {

	public void insert(TipoPago p);

	public List<TipoPago> list();

	public void delete(int idTipoPago);

	List<TipoPago> findBy(TipoPago tipoPago);

	void update(TipoPago r);
}
