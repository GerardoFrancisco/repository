package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.Paciente;

public interface IPacienteDao {

	public void insert(Paciente p);

	public List<Paciente> list();

	public void delete(int idPaciente);

	List<Paciente> findBy(Paciente paciente);

	void update(Paciente r);
}
