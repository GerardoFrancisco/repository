package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IBalonDao;
import pe.edu.upc.entidades.Balon;

public class BalonDaoImpl implements IBalonDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(Balon es) {
		try {
			em.persist(es);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar balones");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Balon> list() {
		List<Balon> listaBalons = new ArrayList<Balon>();

		try {
			Query jpql = em.createQuery("from Balon b");
			listaBalons = (List<Balon>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar balones");
		}
		return listaBalons;
	}

	@Transactional
	@Override
	public void delete(int idBalon) {
		try {
			Balon es = em.find(Balon.class, idBalon);
			em.remove(es);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Balon> findBy(Balon balon) {
		List<Balon> listaBalones = new ArrayList<Balon>();

		try {
			Query jpql = em.createQuery("from Balon t where t.typeBalon like ?1");
			jpql.setParameter(1, "%" + balon.getTypeBalon() + "%");
			listaBalones = (List<Balon>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar balones");
		}
		return listaBalones;
	}
	
	@Transactional
	@Override
	public void update(Balon r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar tipo pago");
		}
	}
}
