package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.TipoPago;
import pe.edu.upc.service.ITipoPagoService;

@Named
@RequestScoped
public class TipoPagoController {
	@Inject
	private ITipoPagoService pService;

	private TipoPago t;
	private TipoPago busqueda;
	List<TipoPago> listaTipoPagos;

	// constructor
	@PostConstruct
	public void init() {
		this.listaTipoPagos = new ArrayList<TipoPago>();
		this.t = new TipoPago();
		this.busqueda = new TipoPago();
		this.listTipoPagos();
	}

	// m�todos

	public String newTipoPago() {
		this.setT(new TipoPago());
		return "tipoPago.xhtml";
	}

	public String updateTipoPago(TipoPago tipoPago) {
		this.setT(tipoPago);
		return "tipoPago.xhtml";
	}

	public void save() {
		try {
			if (t.getIdTipoPago() == 0) {
				pService.insert(t);
			} else {
				pService.update(t);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller tipo pago");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getNamePago().isEmpty()) {
				this.listTipoPagos();
			} else {
				listaTipoPagos = pService.findBy(this.getBusqueda());
			}
		} catch (Exception e) {
			System.out.println("Error al buscar en el controller tipo pago");
		}
	}

	public void listTipoPagos() {
		try {
			listaTipoPagos = pService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller tipo pago");
		}
	}

	public void delete(TipoPago t) {
		try {
			pService.delete(t.getIdTipoPago());
			this.listTipoPagos();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller tipo pago");
		}
	}

	// getters and setters

	public TipoPago getT() {
		return t;
	}

	public void setT(TipoPago t) {
		this.t = t;
	}

	public List<TipoPago> getListaTipoPagos() {
		return listaTipoPagos;
	}

	public void setListaTipoPagos(List<TipoPago> listaTipoPagos) {
		this.listaTipoPagos = listaTipoPagos;
	}

	public TipoPago getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(TipoPago busqueda) {
		this.busqueda = busqueda;
	}

}
