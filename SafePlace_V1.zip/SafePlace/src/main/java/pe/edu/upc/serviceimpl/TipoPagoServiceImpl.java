package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.ITipoPagoDao;
import pe.edu.upc.entidades.TipoPago;
import pe.edu.upc.service.ITipoPagoService;

@Named
public class TipoPagoServiceImpl implements ITipoPagoService {

	@Inject
	private ITipoPagoDao tDao;

	@Override
	public void insert(TipoPago t) {
		tDao.insert(t);
	}

	@Override
	public List<TipoPago> list() {
		// TODO Auto-generated method stub
		return tDao.list();
	}

	@Override
	public void delete(int idTipoPago) {
		// TODO Auto-generated method stub
		tDao.delete(idTipoPago);
	}
	
	@Override
	public List<TipoPago> findBy(TipoPago tipoPago) {
		// TODO Auto-generated method stub
		return tDao.findBy(tipoPago);
	}

	@Override
	public void update(TipoPago t) {
		tDao.update(t);
	}
}
