package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.Usuario;

public interface IUsuarioDao {

	public List<Usuario> listByUsernameYContrasenia(String username, String contrasenia);

}
