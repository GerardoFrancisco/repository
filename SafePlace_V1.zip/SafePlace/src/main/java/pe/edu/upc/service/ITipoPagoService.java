package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entidades.TipoPago;

public interface ITipoPagoService {

	public void insert(TipoPago p);

	public List<TipoPago> list();

	public void delete(int idTipoPago);

	List<TipoPago> findBy(TipoPago tipoPago);

	void update(TipoPago t);
}
