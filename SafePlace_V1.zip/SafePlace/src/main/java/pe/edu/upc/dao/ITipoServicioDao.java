package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.TipoServicio;

public interface ITipoServicioDao {

	public void insert(TipoServicio s);

	public List<TipoServicio> list();

	public void delete(int idTipoServicio);

	List<TipoServicio> findBy(TipoServicio tipoServicio);

	void update(TipoServicio r);
}
