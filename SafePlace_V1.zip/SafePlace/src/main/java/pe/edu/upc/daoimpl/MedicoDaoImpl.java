package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IMedicoDao;
import pe.edu.upc.entidades.Medico;

public class MedicoDaoImpl implements IMedicoDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(Medico m) {
		try {
			em.persist(m);
		} catch (Exception e) {
			System.out.println("Error al insertar medico");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Medico> list() {
		List<Medico> listaMedicos = new ArrayList<Medico>();

		try {
			Query jpql = em.createQuery("from Medico m");
			listaMedicos = (List<Medico>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println("Error al listar medicos");
		}
		return listaMedicos;
	}

	@Transactional
	@Override
	public void delete(int idMedico) {
		try {
			Medico pe = em.find(Medico.class, idMedico);
			em.remove(pe);
		} catch (Exception e) {

			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Medico> findBy(Medico medico) {
		List<Medico> listaMedicos = new ArrayList<Medico>();

		try {
			Query jpql = em.createQuery("from Medico t where t.fullNameMedico like ?1");
			jpql.setParameter(1, "%" + medico.getFullNameMedico() + "%");
			listaMedicos = (List<Medico>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar medico");
		}
		return listaMedicos;
	}
	
	@Transactional
	@Override
	public void update(Medico r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar medico");
		}
	}
}
