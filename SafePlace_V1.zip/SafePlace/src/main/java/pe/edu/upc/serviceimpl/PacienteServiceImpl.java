package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IPacienteDao;
import pe.edu.upc.entidades.Paciente;
import pe.edu.upc.service.IPacienteService;

@Named
public class PacienteServiceImpl implements IPacienteService {

	@Inject
	private IPacienteDao pDao;

	@Override
	public void insert(Paciente e) {
		pDao.insert(e);
	}

	@Override
	public List<Paciente> list() {
		// TODO Auto-generated method stub
		return pDao.list();
	}

	@Override
	public void delete(int idPaciente) {
		// TODO Auto-generated method stub
		pDao.delete(idPaciente);
	}
	
	@Override
	public List<Paciente> findBy(Paciente e) {
		// TODO Auto-generated method stub
		return pDao.findBy(e);
	}

	@Override
	public void update(Paciente t) {
		pDao.update(t);
	}

}
