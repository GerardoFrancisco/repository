package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.ICitaMedicaDao;
import pe.edu.upc.entidades.CitaMedica;
import pe.edu.upc.service.ICitaMedicaService;

@Named
public class CitaMedicaServiceImpl implements ICitaMedicaService {

	@Inject
	private ICitaMedicaDao cDao;

	@Override
	public void insert(CitaMedica c) {
		cDao.insert(c);
	}

	@Override
	public List<CitaMedica> list() {
		// TODO Auto-generated method stub
		return cDao.list();
	}

	@Override
	public void delete(int idCitaMedica) {
		// TODO Auto-generated method stub
		cDao.delete(idCitaMedica);
	}

	@Override
	public List<CitaMedica> findBy(CitaMedica c) {
		// TODO Auto-generated method stub
		return cDao.findBy(c);
	}

	@Override
	public void update(CitaMedica c) {
		cDao.update(c);
	}
}
