package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.CitaMedica;
import pe.edu.upc.entidades.Medico;
import pe.edu.upc.entidades.Reserva;
import pe.edu.upc.service.ICitaMedicaService;
import pe.edu.upc.service.IMedicoService;
import pe.edu.upc.service.IReservaService;

@Named
@RequestScoped
public class CitaMedicaController {
	@Inject
	private ICitaMedicaService cService;

	@Inject
	private IMedicoService mService;
	
	@Inject
	private IReservaService rService;

	private CitaMedica c;
	private CitaMedica busqueda;
	List<CitaMedica> listaCitaMedicas;

	List<Medico> listaMedicos;
	List<Reserva> listaReservas;

	// constructor
	@PostConstruct
	public void init() {
		this.listaCitaMedicas = new ArrayList<CitaMedica>();
		this.c = new CitaMedica();
		this.busqueda = new CitaMedica();
		busqueda.setMedico(new Medico());
		this.listaMedicos = new ArrayList<Medico>();
		this.listaReservas = new ArrayList<Reserva>();
		this.listCitaMedicas();
		this.listMedicos();
		this.listReservas();
	}

	// m�todos
	
	public String updateCitaMedica(CitaMedica citaMedica) {
		this.setC(citaMedica);
		return "citaMedica.xhtml";
	}

	public void save() {
		try {
			if (c.getIdCitaMedica() == 0) {
				cService.insert(c);
			} else {
				cService.update(c);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller cita medica");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getMedico().getFullNameMedico().isEmpty()) {
				this.listCitaMedicas();
			} else {
				listaCitaMedicas = cService.findBy(this.getBusqueda());
			}
		} catch (Exception e) {
			System.out.println("Error al buscar en el controller cita medica");
		}
	}

	public String newCitaMedica() {
		this.setC(new CitaMedica());
		this.listMedicos();
		this.listReservas();
		return "citaMedica.xhtml";
	}

	public void listCitaMedicas() {
		try {
			listaCitaMedicas = cService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller reserva");
		}
	}

	public void listReservas() {
		try {
			listaReservas = rService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller establecimientos");
		}
	}
	
	public void listMedicos() {
		try {
			listaMedicos = mService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller pacientes");
		}
	}

	public void delete(CitaMedica c) {
		try {
			cService.delete(c.getIdCitaMedica());
			this.listCitaMedicas();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller reserva");
		}
	}

	// getters and setters



	public List<CitaMedica> getListaCitaMedicas() {
		return listaCitaMedicas;
	}

	public CitaMedica getC() {
		return c;
	}

	public void setC(CitaMedica c) {
		this.c = c;
	}

	public void setListaCitaMedicas(List<CitaMedica> listaCitaMedicas) {
		this.listaCitaMedicas = listaCitaMedicas;
	}

	public List<Medico> getListaMedicos() {
		return listaMedicos;
	}

	public void setListaMedicos(List<Medico> listaMedicos) {
		this.listaMedicos = listaMedicos;
	}

	public List<Reserva> getListaReservas() {
		return listaReservas;
	}

	public void setListaReservas(List<Reserva> listaReservas) {
		this.listaReservas = listaReservas;
	}

	public CitaMedica getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(CitaMedica busqueda) {
		this.busqueda = busqueda;
	}


}
