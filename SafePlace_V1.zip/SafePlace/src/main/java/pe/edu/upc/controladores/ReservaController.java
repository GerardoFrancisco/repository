package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Establecimiento;
import pe.edu.upc.entidades.Paciente;
import pe.edu.upc.entidades.Reserva;
import pe.edu.upc.service.IEstablecimientoService;
import pe.edu.upc.service.IPacienteService;
import pe.edu.upc.service.IReservaService;

@Named
@RequestScoped
public class ReservaController {
	@Inject
	private IReservaService rService;

	@Inject
	private IEstablecimientoService eService;
	
	@Inject
	private IPacienteService pService;

	private Reserva r;
	private Reserva busqueda;
	List<Reserva> listaReservas;

	List<Establecimiento> listaEstablecimientos;
	List<Paciente> listaPacientes;

	// constructor
	@PostConstruct
	public void init() {
		this.listaReservas = new ArrayList<Reserva>();
		this.r = new Reserva();
		this.busqueda = new Reserva();
		busqueda.setPaciente(new Paciente());
		this.listaEstablecimientos = new ArrayList<Establecimiento>();
		this.listReservas();
		this.listEstablecimientos();
		this.listPacientes();
	}

	// m�todos

	public String updateReserva(Reserva reserva) {
		this.setR(reserva);
		return "reserva.xhtml";
	}

	public void save() {
		try {
			if (r.getIdReserva() == 0) {
				rService.insert(r);
			} else {
				rService.update(r);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller reserva");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getPaciente().getNamePaciente().isEmpty()) {
				this.listReservas();
			} else {
				listaReservas = rService.findBy(this.getBusqueda());
			}
		} catch (Exception m) {
			System.out.println("Error al buscar en el controller paciente");
		}
	}
	
	public String newReserva() {
		this.setR(new Reserva());
		this.listEstablecimientos();
		this.listPacientes();
		return "reserva.xhtml";
	}

	public void listReservas() {
		try {
			listaReservas = rService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller reserva");
		}
	}

	public void listEstablecimientos() {
		try {
			listaEstablecimientos = eService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller establecimientos");
		}
	}
	
	public void listPacientes() {
		try {
			listaPacientes = pService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller pacientes");
		}
	}

	public void delete(Reserva r) {
		try {
			rService.delete(r.getIdReserva());
			this.listReservas();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller reserva");
		}
	}

	// getters and setters

	public Reserva getR() {
		return r;
	}

	public void setR(Reserva r) {
		this.r = r;
	}

	public List<Reserva> getListaReservas() {
		return listaReservas;
	}

	public void setListaReservas(List<Reserva> listaReservas) {
		this.listaReservas = listaReservas;
	}

	public List<Establecimiento> getListaEstablecimientos() {
		return listaEstablecimientos;
	}

	public void setListaEstablecimientos(List<Establecimiento> listaEstablecimientos) {
		this.listaEstablecimientos = listaEstablecimientos;
	}

	public List<Paciente> getListaPacientes() {
		return listaPacientes;
	}

	public void setListaPacientes(List<Paciente> listaPacientes) {
		this.listaPacientes = listaPacientes;
	}

	public Reserva getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(Reserva busqueda) {
		this.busqueda = busqueda;
	}

}
