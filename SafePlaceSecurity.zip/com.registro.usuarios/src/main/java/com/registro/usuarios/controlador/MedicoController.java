package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.Medico;
import com.registro.usuarios.servicio.IMedicoService;



@Controller
@RequestMapping("/medicos")
public class MedicoController {

	@Autowired
	private IMedicoService medService;

	@GetMapping("/nuevomedico")
	public String newMedico(Model model) {
		model.addAttribute("m", new Medico());
		return "medico/frmRegistroMedico";
	}

	@PostMapping("/guardarMedico")
	public String saveMedico(@Validated Medico med, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "medico/frmRegistroMedico";
		} else {
			medService.insert(med);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			return "redirect:/medicos/nuevomedico";
		}

	}

	@GetMapping("/listarmedico")
	public String listMedico(Model model) {
		try {
			model.addAttribute("listaMedicos", medService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/medico/frmListaMedicos";
	}

	@RequestMapping("/eliminarMedico")
	public String deleteMedico(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				medService.delete(id);
				model.put("listaMedicos", medService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "medico/frmListaMedicos";
	}

	@RequestMapping("/irmodificarmedico/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Medico> objMed = medService.listId(id);
		model.addAttribute("medi", objMed.get());
		return "medico/frmActualizaMedico";
	}

	@PostMapping("/modificarMedico")
	public String updateMedico(Medico me) {
		medService.updateMedico(me);
		return "redirect:/medicos/listarmedico";
	}

}
