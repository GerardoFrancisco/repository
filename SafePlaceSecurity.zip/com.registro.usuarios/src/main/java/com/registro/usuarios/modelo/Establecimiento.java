package com.registro.usuarios.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Establecimiento")
public class Establecimiento {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idEstablecimiento;

	@Column(name = "adressEstablecimiento", nullable = false, length = 120)
	private String adressEstablecimiento;

	@Column(name = "nameEstablecimiento", nullable = false, length = 100)
	private String nameEstablecimiento;


	public Establecimiento() {
		super();
		//TODO Auto-generated constructor stub
	}

	public Establecimiento(int idEstablecimiento, String adressEstablecimiento, String nameEstablecimiento) {
		super();
		this.idEstablecimiento = idEstablecimiento;
		this.adressEstablecimiento = adressEstablecimiento;
		this.nameEstablecimiento = nameEstablecimiento;
	}

	public int getIdEstablecimiento() {
		return idEstablecimiento;
	}

	public void setIdEstablecimiento(int idEstablecimiento) {
		this.idEstablecimiento = idEstablecimiento;
	}

	public String getAdressEstablecimiento() {
		return adressEstablecimiento;
	}

	public void setAdressEstablecimiento(String adressEstablecimiento) {
		this.adressEstablecimiento = adressEstablecimiento;
	}

	public String getNameEstablecimiento() {
		return nameEstablecimiento;
	}

	public void setNameEstablecimiento(String nameEstablecimiento) {
		this.nameEstablecimiento = nameEstablecimiento;
	}



	
}
