package com.registro.usuarios.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.Medico;



@Repository

public interface MedicoRepository extends JpaRepository<Medico , Integer> {
}
