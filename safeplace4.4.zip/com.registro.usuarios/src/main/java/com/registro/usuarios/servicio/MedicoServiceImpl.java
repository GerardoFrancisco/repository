package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.Medico;
import com.registro.usuarios.repositorio.MedicoRepository;




@Service
public class MedicoServiceImpl implements IMedicoService{

	
	@Autowired
	private MedicoRepository medicoRepository;
	
	@Override
	public void insert(Medico medico) {
		// TODO Auto-generated method stub
		medicoRepository.save(medico);
	}
	@Override
	public List<Medico> list() {
		// TODO Auto-generated method stub
		return medicoRepository.findAll();
	}

	@Override
	public void delete(int idMedico) {
		// TODO Auto-generated method stub
		medicoRepository.deleteById(idMedico);
	}

	@Override
	public Optional<Medico> listId(int idMedico) {
		// TODO Auto-generated method stub
		return medicoRepository.findById(idMedico);
	}
	@Override
	public void updateMedico(Medico medico) {
		medicoRepository.save(medico);
		
	}

}
	
	
	
	
	
	
