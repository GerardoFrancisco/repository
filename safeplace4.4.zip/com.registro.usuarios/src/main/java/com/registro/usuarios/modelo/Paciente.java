package com.registro.usuarios.modelo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Paciente")
public class Paciente {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idPaciente;

	@Column(name = "fullNamePaciente", nullable = false, length = 44)
	private String fullNamePaciente;

	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "birthDatePaciente", nullable = false)
	private Date birthDatePaciente;

	@Column(name = "phonePaciente", nullable = false, length = 9)
	private String phonePaciente;

	public Paciente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Paciente(int idPaciente, String fullNamePaciente, Date birthDatePaciente, String phonePaciente) {
		super();
		this.idPaciente = idPaciente;
		this.fullNamePaciente = fullNamePaciente;
		this.birthDatePaciente = birthDatePaciente;
		this.phonePaciente = phonePaciente;
	}

	public int getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getFullNamePaciente() {
		return fullNamePaciente;
	}

	public void setFullNamePaciente(String fullNamePaciente) {
		this.fullNamePaciente = fullNamePaciente;
	}

	public Date getBirthDatePaciente() {
		return birthDatePaciente;
	}

	public void setBirthDatePaciente(Date birthDatePaciente) {
		this.birthDatePaciente = birthDatePaciente;
	}

	public String getPhonePaciente() {
		return phonePaciente;
	}

	public void setPhonePaciente(String phonePaciente) {
		this.phonePaciente = phonePaciente;
	}

}
