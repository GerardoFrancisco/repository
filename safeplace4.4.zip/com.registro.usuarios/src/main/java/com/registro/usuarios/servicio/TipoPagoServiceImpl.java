package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.TipoPago;
import com.registro.usuarios.repositorio.ITipoPagoRepository;



@Service
public class TipoPagoServiceImpl implements ITipoPagoService {

	@Autowired
	private ITipoPagoRepository tpagoRepository;
	
	@Override
	public void insert(TipoPago tipopago) {
		// TODO Auto-generated method stub
		tpagoRepository.save(tipopago);
	}

	@Override
	public List<TipoPago> list() {
		// TODO Auto-generated method stub
		return tpagoRepository.findAll();
	}

	@Override
	public void delete(int idTPago) {
		// TODO Auto-generated method stub
		tpagoRepository.deleteById(idTPago);
	}

	@Override
	public Optional<TipoPago> listId(int idTPago) {
		// TODO Auto-generated method stub
		return tpagoRepository.findById(idTPago);
	}

	@Override
	public void updateTipoPago(TipoPago tipopago) {
		
		tpagoRepository.save(tipopago);
	}

}
