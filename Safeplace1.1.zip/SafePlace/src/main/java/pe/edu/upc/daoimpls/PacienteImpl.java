package pe.edu.upc.daoimpls;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import pe.edu.upc.daointerfaces.IPacienteDao;
import pe.edu.upc.entities.Paciente;

public class PacienteImpl implements IPacienteDao {
	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Override
	public void insert(Paciente p) {
		try {
			em.persist(p);

		} catch (Exception e) {
			System.out.println("Error al inerta en Persona Dao");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Paciente> list() {

		List<Paciente> listaPaciente = new ArrayList<Paciente>();
		try {
			Query jpql = em.createQuery("from paciente p");
			listaPaciente = (List<Paciente>)jpql.getResultList();
		} catch (Exception e) {
			System.out.println("Error al listar en el DAO de persona");
		}

		return listaPaciente;
	}
}
