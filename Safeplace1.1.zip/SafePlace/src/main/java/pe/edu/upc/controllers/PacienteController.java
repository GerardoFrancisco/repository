package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entities.Paciente;
import pe.edu.upc.serviceinterfaces.IPacienteService;

@Named
@RequestScoped
public class PacienteController {
	@Inject
	private IPacienteService pService;
	// atributos
	private Paciente p;
	List<Paciente> listaPaciente;

	//METODOS
	
	public void init() {
		this.listaPaciente = new ArrayList<Paciente>();
		this.p = new Paciente();
	}
	
	public String newPaciente() {
		this.setP(new Paciente());
		return "paciente.xhtml";
	}
	
	public void insert() {
		
		try {
			pService.insert(p);
		} catch (Exception e) {
			System.out.println("Error ocurrio en el controlador de paciente insertar");
		}
	}
	public void list() {
		try {
			listaPaciente = pService.list();
		} catch (Exception e) {
			System.out.println("Error en la lista paciente controller");
		}
	}
	
	/// GETTERS AND SETTERS
	public Paciente getP() {
		return p;
	}

	public void setP(Paciente p) {
		this.p = p;
	}

	public List<Paciente> getListaPaciente() {
		return listaPaciente;
	}

	public void setListaPaciente(List<Paciente> listaPaciente) {
		this.listaPaciente = listaPaciente;
	}

	

}
