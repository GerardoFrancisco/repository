package pe.edu.upc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Paciente")
public class Paciente {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idPaciente;
	
	@Column(name = "namePaciente", nullable = false, length = 47)
	private String namePaciente;
	
	@Column(name = "birthDatePaciente", nullable = false)
	private Date birthDatePaciente;
	
	@Column(name = "phonePaciente", nullable = false, length = 45)
	private String phonePaciente;

	public Paciente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Paciente(int idPaciente, String namePaciente, Date birthDatePaciente, String phonePaciente) {
		super();
		this.idPaciente = idPaciente;
		this.namePaciente = namePaciente;
		this.birthDatePaciente = birthDatePaciente;
		this.phonePaciente = phonePaciente;
	}

	public int getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getNamePaciente() {
		return namePaciente;
	}

	public void setNamePaciente(String namePaciente) {
		this.namePaciente = namePaciente;
	}

	public Date getBirthDatePaciente() {
		return birthDatePaciente;
	}

	public void setBirthDatePaciente(Date birthDatePaciente) {
		this.birthDatePaciente = birthDatePaciente;
	}

	public String getPhonePaciente() {
		return phonePaciente;
	}

	public void setPhonePaciente(String phonePaciente) {
		this.phonePaciente = phonePaciente;
	}

}
