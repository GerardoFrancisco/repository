package pe.edu.upc.demo.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.demo.entities.Balon;
import pe.edu.upc.demo.serviceinterface.IBalonService;

@Controller
@RequestMapping("/balones")
public class BalonController {
	@Autowired
	private IBalonService balService;

	@GetMapping("/nuevo")
	public String newBalon(Model model) {
		model.addAttribute("p", new Balon());
		return "balon/frmRegistro";
	}

	@PostMapping("/guardar")
	public String saveBalon(@Valid Balon bal, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "balon/frmRegistro";
		} else {
			balService.insert(bal);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			return "redirect:/balones/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listBalon(Model model) {
		try {
			model.addAttribute("listaBalones", balService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/balon/frmLista";
	}

	@RequestMapping("/eliminar")
	public String deleteBalon(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				balService.delete(id);
				model.put("listaBalones", balService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "balon/frmLista";
	}

	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Balon> objBal = balService.listId(id);
		model.addAttribute("bals", objBal.get());
		return "balon/frmActualiza";
	}

}
