package pe.edu.upc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstablecimientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstablecimientoApplication.class, args);
	}

}
