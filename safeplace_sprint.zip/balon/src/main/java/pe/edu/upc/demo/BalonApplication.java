package pe.edu.upc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BalonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BalonApplication.class, args);
	}

}
