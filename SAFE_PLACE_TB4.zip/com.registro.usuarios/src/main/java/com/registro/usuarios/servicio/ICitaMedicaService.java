package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.CitaMedica;




public interface ICitaMedicaService {
	public void insert(CitaMedica citamedica);

	public List<CitaMedica> list();
	
	public void delete(int idCitaMedica);
	Optional<CitaMedica>listId(int idCitaMedica);

	public void updateCitaMedica(CitaMedica citamedica);
}
