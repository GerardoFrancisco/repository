package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.Establecimiento;
import com.registro.usuarios.servicio.IEstablecimientoService;
import com.registro.usuarios.servicio.ITipoServicioService;



@Controller
@RequestMapping("/establecimientos")
public class EstablecimientoController {

	@Autowired
	private ITipoServicioService lsService;

	@Autowired
	private IEstablecimientoService estService;

	@GetMapping("/nuevoEstablecimiento")
	public String newEstablecimiento(Model model) {
		model.addAttribute("p", new Establecimiento());
		model.addAttribute("listaServicios", lsService.list());
		return "establecimiento/frmRegistroEstablecimiento";
	}

	@PostMapping("/guardarEstablecimiento")
	public String saveEstablecimiento(@Validated Establecimiento est, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "establecimiento/frmRegistroEstablecimiento";
		} else {
			estService.insert(est);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			return "redirect:/establecimientos/nuevoEstablecimiento";
		}

	}

	@GetMapping("/listarEstablecimiento")
	public String listEstablecimiento(Model model) {
		try {
			model.addAttribute("listaEstablecimientos", estService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/establecimiento/frmListaEstablecimiento";
	}

	@RequestMapping("/eliminarEstablecimiento")
	public String deleteEstablecimiento(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				estService.delete(id);
				model.put("listaEstablecimientos", estService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "establecimiento/frmListaEstablecimiento";
	}

	@RequestMapping("/irmodificarEstablecimiento/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Establecimiento> objEst = estService.listId(id);
		model.addAttribute("ests", objEst.get());
		model.addAttribute("listaServicios", lsService.list());
		return "establecimiento/frmActualizaEstablecimiento";
	}

	@PostMapping("/modificarEstablecimiento")
	public String updateEstablecimiento(Establecimiento est) {
		estService.updateEstablecimiento(est);
		return "redirect:/establecimientos/listarEstablecimiento";
	}

}
