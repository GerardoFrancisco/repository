package com.registro.usuarios.controlador;
import java.util.Map;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.TipoServicio;
import com.registro.usuarios.servicio.ITipoPagoService;
import com.registro.usuarios.servicio.ITipoServicioService;


@Controller
@RequestMapping("/tiposervicios")
public class TipoServicioController {

	@Autowired
	private ITipoPagoService tpService;
	
	@Autowired
	private ITipoServicioService tsService;
	
	@GetMapping("/nuevo")
	public String newTipoServicio(Model model) {
		model.addAttribute("p", new TipoServicio());
		model.addAttribute("listaTipoPagos", tpService.list());
		return "tiposervicio/frmRegistro";
	}
	
	@PostMapping("/guardar")
	public String saveTipoServicio(@Validated TipoServicio ts, BindingResult binRes) {
		if (binRes.hasErrors()) {
			return "tiposervicio/frmRegistro";
		} else {
			tsService.insert(ts);
			return "redirect:/tiposervicios/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listServicio(Model model) {
		try {
			model.addAttribute("listaServicios", tsService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/tiposervicio/frmLista";
	}

	
	@RequestMapping("/eliminar")
	public String deleteTipoServicio(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				tsService.delete(id);
				model.put("listaServicios", tsService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "tiposervicio/frmLista";
	}

	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<TipoServicio> objTs = tsService.listId(id);
		model.addAttribute("tss", objTs.get());
		model.addAttribute("listaTipoPagos",tpService.list());
		return "tiposervicio/frmActualiza";
	}

	@PostMapping("/modificar")
	public String updateTipoServicio(TipoServicio t) {
		tsService.updateTipoServicio(t);
		return "redirect:/tiposervicios/listar";
	}
	
}
