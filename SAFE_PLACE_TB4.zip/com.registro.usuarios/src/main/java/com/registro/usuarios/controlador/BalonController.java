package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.Balon;
import com.registro.usuarios.servicio.IBalonService;
import com.registro.usuarios.servicio.IEstablecimientoService;

@Controller
@RequestMapping("/balones")
public class BalonController {
	@Autowired
	private IEstablecimientoService estService;

	@Autowired
	private IBalonService balService;

	@GetMapping("/nuevoBalon")
	public String newBalon(Model model) {
		model.addAttribute("p", new Balon());
		model.addAttribute("listaEstablecimientos", estService.list());
		return "balon/frmRegistroBalon";
	}

	@PostMapping("/guardarBalon")
	public String saveBalon(@Validated Balon bal, BindingResult binRes) {
		if (binRes.hasErrors()) {
			return "balon/frmRegistroBalon";
		} else {
			balService.insert(bal);
			return "redirect:/balones/nuevoBalon";
		}

	}

	@GetMapping("/listarBalon")
	public String listBalon(Model model) {
		try {
			model.addAttribute("listaBalones", balService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/balon/frmListaBalon";
	}

	@RequestMapping("/eliminarBalon")
	public String deleteBalon(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				balService.delete(id);
				model.put("listaBalones", balService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "balon/frmListaBalon";
	}

	@RequestMapping("/irmodificarBalon/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Balon> objBal = balService.listId(id);
		model.addAttribute("bals", objBal.get());
		model.addAttribute("listaEstablecimientos",estService.list());
		return "balon/frmActualizaBalon";
	}

	@PostMapping("/modificarBalon")
	public String updateBalon(Balon p) {
		balService.updateBalon(p);
		return "redirect:/balones/listarBalon";
	}
}
