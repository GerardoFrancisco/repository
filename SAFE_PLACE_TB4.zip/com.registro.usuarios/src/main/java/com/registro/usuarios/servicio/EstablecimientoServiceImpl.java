package com.registro.usuarios.servicio;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.Establecimiento;
import com.registro.usuarios.repositorio.IEstablecimientoRepository;



@Service
public class EstablecimientoServiceImpl implements IEstablecimientoService {

	@Autowired
	private IEstablecimientoRepository establecimientoRepository;
	
	@Override
	public void insert(Establecimiento establecimiento) {
		// TODO Auto-generated method stub
		establecimientoRepository.save(establecimiento);
	}

	@Override
	public List<Establecimiento> list() {
		// TODO Auto-generated method stub
		return establecimientoRepository.findAll();
	}

	@Override
	public void delete(int idEstablecimiento) {
		// TODO Auto-generated method stub
		establecimientoRepository.deleteById(idEstablecimiento);
	}

	@Override
	public Optional<Establecimiento> listId(int idEstablecimiento) {
		// TODO Auto-generated method stub
		return establecimientoRepository.findById(idEstablecimiento);
	}

	@Override
	public void updateEstablecimiento(Establecimiento establecimiento) {
		
		establecimientoRepository.save(establecimiento);
	}

}
