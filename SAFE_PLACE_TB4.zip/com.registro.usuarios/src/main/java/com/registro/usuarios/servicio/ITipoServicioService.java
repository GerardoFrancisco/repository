package com.registro.usuarios.servicio;
import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.TipoServicio;


public interface ITipoServicioService {
	public void insert(TipoServicio tiposervicio);

	public List<TipoServicio> list();

	public void delete(int idTipoServicio);

	Optional<TipoServicio> listId(int idTipoServicio);
	
	public void updateTipoServicio (TipoServicio tiposervicio);
}
