package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.TipoPago;



public interface ITipoPagoService {
	public void insert(TipoPago tipopago);

	public List<TipoPago> list();
	
	public void delete(int idTPago);
	Optional<TipoPago>listId(int idTPago);
	public void updateTipoPago(TipoPago tipopago);
}
