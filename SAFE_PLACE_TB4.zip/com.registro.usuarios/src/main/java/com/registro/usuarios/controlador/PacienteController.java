package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.Paciente;
import com.registro.usuarios.servicio.IPacienteService;


@Controller
@RequestMapping("/pacientes")
public class PacienteController {

	@Autowired
	private IPacienteService pacService;

	@GetMapping("/nuevopaciente")
	public String newPaciente(Model model) {
		model.addAttribute("p", new Paciente());
		return "paciente/frmRegistroPaciente";
	}

	@PostMapping("/guardar")
	public String savePaciente(@Validated Paciente pac, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "paciente/frmRegistroPaciente";
		} else {
			pacService.insert(pac);
			model.addAttribute("mensaje", "Se registró correctamente!");
			return "redirect:/pacientes/nuevopaciente";
		}

	}

	@GetMapping("/listarpaciente")
	public String listPaciente(Model model) {
		try {
			model.addAttribute("listaPacientes", pacService.list());
		} catch (Exception e) {
			model.addAttribute("Error", e.getMessage());
		}
		return "/paciente/frmListaPaciente";
	}

	@RequestMapping("/eliminar")
	public String deletePaciente(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				pacService.delete(id);// eliminar
				model.put("listaPacientes", pacService.list());
			}
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}

		return "paciente/frmListaPaciente";
	}

	@RequestMapping("/irmodificarpaciente/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		
		Optional<Paciente>objPacie=pacService.listId(id);
		model.addAttribute("paci", objPacie.get());
		return "paciente/frmActualizarPaci";
	}
	@PostMapping("/modificarPaciente")
	public String updatePaciente(Paciente pa) {
		pacService.updatePaciente(pa);
		return "redirect:/pacientes/listarpaciente";
	}
}
