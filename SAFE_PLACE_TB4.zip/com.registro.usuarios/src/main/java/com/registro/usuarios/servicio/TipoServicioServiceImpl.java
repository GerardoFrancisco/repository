package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.TipoServicio;
import com.registro.usuarios.repositorio.ITipoServicioRepository;

@Service
public class TipoServicioServiceImpl implements ITipoServicioService {

	@Autowired
	private ITipoServicioRepository tiposervicioRepository;

	@Override
	public void insert(TipoServicio tiposervicio) {
		// TODO Auto-generated method stub
		tiposervicioRepository.save(tiposervicio);
	}

	@Override
	public List<TipoServicio> list() {
		// TODO Auto-generated method stub
		return tiposervicioRepository.findAll();
	}

	@Override
	public void delete(int idTipoServicio) {
		// TODO Auto-generated method stub
		tiposervicioRepository.deleteById(idTipoServicio);
	}

	@Override
	public Optional<TipoServicio> listId(int idTipoServicio) {
		// TODO Auto-generated method stub
		return tiposervicioRepository.findById(idTipoServicio);
	}

	@Override
	public void updateTipoServicio(TipoServicio tiposervicio) {
		// TODO Auto-generated method stub
		tiposervicioRepository.save(tiposervicio);
	}

}
