package com.registro.usuarios.modelo;




import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Reserve")
public class Reserve {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idReserve;

	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "fecha", nullable = false)
	private Date fecha;

	@Column(name = "tipoEntrega", nullable = false, length = 20)
	private String tipoEntrega;

	@ManyToOne
	@JoinColumn(name = "idEstablecimiento")
	private Establecimiento establecimiento;
	
	@ManyToOne
	@JoinColumn(name = "idPaciente")
	private Paciente paciente;
	
	public Reserve() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Reserve(int idReserve, Date fecha, String tipoEntrega, Establecimiento establecimiento, Paciente paciente) {
		super();
		this.idReserve = idReserve;
		this.fecha = fecha;
		this.tipoEntrega = tipoEntrega;
		this.establecimiento = establecimiento;
		this.paciente = paciente;
	}

	public int getIdReserve() {
		return idReserve;
	}

	public void setIdReserve(int idReserve) {
		this.idReserve = idReserve;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getTipoEntrega() {
		return tipoEntrega;
	}

	public void setTipoEntrega(String tipoEntrega) {
		this.tipoEntrega = tipoEntrega;
	}

	public Establecimiento getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(Establecimiento establecimiento) {
		this.establecimiento = establecimiento;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	
	
}