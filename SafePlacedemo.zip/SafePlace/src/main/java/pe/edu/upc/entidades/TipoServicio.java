package pe.edu.upc.entidades;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TipoServicio")
public class TipoServicio {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTipoServicio;

	@Column(name = "nameServicio", nullable = false, length = 45)
	private String nameServicio;
	
	@ManyToOne
	@JoinColumn(name = "idTipoPago", nullable = false)
	private TipoPago tipoPago;

	public TipoServicio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TipoServicio(int idTipoServicio, String nameServicio, TipoPago tipoPago) {
		super();
		this.idTipoServicio = idTipoServicio;
		this.nameServicio = nameServicio;
		this.tipoPago = tipoPago;
	}

	public int getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(int idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public String getNameServicio() {
		return nameServicio;
	}

	public void setNameServicio(String nameServicio) {
		this.nameServicio = nameServicio;
	}

	public TipoPago getTipoPago() {
		return tipoPago;
	}

	public void setTipoPago(TipoPago tipoPago) {
		this.tipoPago = tipoPago;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idTipoServicio, nameServicio, tipoPago);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoServicio other = (TipoServicio) obj;
		return idTipoServicio == other.idTipoServicio && Objects.equals(nameServicio, other.nameServicio)
				&& Objects.equals(tipoPago, other.tipoPago);
	}
	
	
}
