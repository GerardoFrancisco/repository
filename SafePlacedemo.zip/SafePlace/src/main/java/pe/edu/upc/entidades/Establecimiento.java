package pe.edu.upc.entidades;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Establecimiento")
public class Establecimiento {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idEstablecimiento;

	@Column(name = "adressEstablecimiento", nullable = false, length = 120)
	private String adressEstablecimiento;

	@Column(name = "nameEstablecimiento", nullable = false, length = 100)
	private String nameEstablecimiento;

	@Column(name = "reserva", nullable = false)
	private Boolean reserva;

	@ManyToOne
	@JoinColumn(name = "idTipoServicio", nullable = false)
	private TipoServicio tipoServicio;

	public Establecimiento() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Establecimiento(int idEstablecimiento, String adressEstablecimiento, String nameEstablecimiento,
			Boolean reserva, TipoServicio tipoServicio) {
		super();
		this.idEstablecimiento = idEstablecimiento;
		this.adressEstablecimiento = adressEstablecimiento;
		this.nameEstablecimiento = nameEstablecimiento;
		this.reserva = reserva;
		this.tipoServicio = tipoServicio;
	}

	public int getIdEstablecimiento() {
		return idEstablecimiento;
	}

	public void setIdEstablecimiento(int idEstablecimiento) {
		this.idEstablecimiento = idEstablecimiento;
	}

	public String getAdressEstablecimiento() {
		return adressEstablecimiento;
	}

	public void setAdressEstablecimiento(String adressEstablecimiento) {
		this.adressEstablecimiento = adressEstablecimiento;
	}

	public String getNameEstablecimiento() {
		return nameEstablecimiento;
	}

	public void setNameEstablecimiento(String nameEstablecimiento) {
		this.nameEstablecimiento = nameEstablecimiento;
	}

	public Boolean getReserva() {
		return reserva;
	}

	public void setReserva(Boolean reserva) {
		this.reserva = reserva;
	}

	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(TipoServicio tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	@Override
	public int hashCode() {
		return Objects.hash(adressEstablecimiento, idEstablecimiento, nameEstablecimiento, reserva, tipoServicio);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Establecimiento other = (Establecimiento) obj;
		return Objects.equals(adressEstablecimiento, other.adressEstablecimiento)
				&& idEstablecimiento == other.idEstablecimiento
				&& Objects.equals(nameEstablecimiento, other.nameEstablecimiento)
				&& Objects.equals(reserva, other.reserva) && Objects.equals(tipoServicio, other.tipoServicio);
	}

}
