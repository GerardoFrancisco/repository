package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Establecimiento;
import pe.edu.upc.entidades.TipoServicio;
import pe.edu.upc.service.IEstablecimientoService;
import pe.edu.upc.service.ITipoServicioService;

@Named
@RequestScoped
public class EstablecimientoController {
	@Inject
	private IEstablecimientoService eService;

	@Inject
	private ITipoServicioService bService;

	private Establecimiento e;
	private Establecimiento busqueda;
	
	List<Establecimiento> listaEstablecimientos;

	List<TipoServicio> listaTipoServicios;

	// constructor
	@PostConstruct
	public void init() {
		this.listaEstablecimientos = new ArrayList<Establecimiento>();
		this.e = new Establecimiento();
		this.busqueda = new Establecimiento();
		this.listaTipoServicios = new ArrayList<TipoServicio>();
		this.listEstablecimientos();
		this.listTipoServicios();
	}

	// m�todos

	public String updateEstablecimiento(Establecimiento establecimiento) {
		this.setE(establecimiento);
		return "establecimiento.xhtml";
	}

	public void save() {
		try {
			if (e.getIdEstablecimiento() == 0) {
				eService.insert(e);
			} else {
				eService.update(e);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller establecimiento");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getNameEstablecimiento().isEmpty()) {
				this.listEstablecimientos();
			} else {
				listaEstablecimientos = eService.findBy(this.getBusqueda());
			}
		} catch (Exception e) {
			System.out.println("Error al buscar en el controller establecimiento");
		}
	}
	
	public String newEstablecimiento() {
		this.setE(new Establecimiento());
		this.listTipoServicios();
		return "establecimiento.xhtml";
	}

	public void listEstablecimientos() {
		try {
			listaEstablecimientos = eService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller establecimiento");
		}
	}

	public void listTipoServicios() {
		try {
			listaTipoServicios = bService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller tipo Servicios");
		}
	}

	public void delete(Establecimiento e) {
		try {
			eService.delete(e.getIdEstablecimiento());
			this.listEstablecimientos();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller establecimiento");
		}
	}

	// getters and setters

	public Establecimiento getE() {
		return e;
	}

	public void setE(Establecimiento e) {
		this.e = e;
	}

	public List<Establecimiento> getListaEstablecimientos() {
		return listaEstablecimientos;
	}

	public void setListaEstablecimientos(List<Establecimiento> listaEstablecimientos) {
		this.listaEstablecimientos = listaEstablecimientos;
	}

	public List<TipoServicio> getListaTipoServicios() {
		return listaTipoServicios;
	}

	public void setListaTipoServicios(List<TipoServicio> listaTipoServicios) {
		this.listaTipoServicios = listaTipoServicios;
	}

	public Establecimiento getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(Establecimiento busqueda) {
		this.busqueda = busqueda;
	}

}
