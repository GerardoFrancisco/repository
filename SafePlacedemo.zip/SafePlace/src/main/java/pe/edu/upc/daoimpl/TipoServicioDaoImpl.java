package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.ITipoServicioDao;
import pe.edu.upc.entidades.TipoServicio;

public class TipoServicioDaoImpl implements ITipoServicioDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(TipoServicio t) {
		try {
			em.persist(t);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar tipo servicio");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TipoServicio> list() {
		List<TipoServicio> listaTipoServicios = new ArrayList<TipoServicio>();

		try {
			Query jpql = em.createQuery("from TipoServicio r");
			listaTipoServicios = (List<TipoServicio>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar tipo servicios");
		}
		return listaTipoServicios;
	}

	@Transactional
	@Override
	public void delete(int idTipoServicio) {
		try {
			TipoServicio r = em.find(TipoServicio.class, idTipoServicio);
			em.remove(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TipoServicio> findBy(TipoServicio tipoServicio) {
		List<TipoServicio> listaTipoServicios = new ArrayList<TipoServicio>();

		try {
			Query jpql = em.createQuery("from TipoServicio t where t.nameServicio like ?1");
			jpql.setParameter(1, "%" + tipoServicio.getNameServicio() + "%");
			listaTipoServicios = (List<TipoServicio>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar tipo servicios");
		}
		return listaTipoServicios;
	}
	
	@Transactional
	@Override
	public void update(TipoServicio r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar tipo servicios");
		}
	}
}
