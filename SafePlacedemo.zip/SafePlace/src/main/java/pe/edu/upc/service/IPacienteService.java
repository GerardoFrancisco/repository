package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entidades.Paciente;

public interface IPacienteService {

	public void insert(Paciente p);

	public List<Paciente> list();

	public void delete(int idPaciente);

	void update(Paciente t);

	List<Paciente> findBy(Paciente e);
}
