package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.TipoPago;
import pe.edu.upc.entidades.TipoServicio;
import pe.edu.upc.service.ITipoPagoService;
import pe.edu.upc.service.ITipoServicioService;

@Named
@RequestScoped
public class TipoServicioController {
	@Inject
	private ITipoServicioService pService;
	
	@Inject
	private ITipoPagoService tService;

	private TipoServicio t;
	private TipoServicio busqueda;
	List<TipoServicio> listaTipoServicios;
	
	List<TipoPago> listaTipoPagos;

	// constructor
	@PostConstruct
	public void init() {
		this.listaTipoServicios = new ArrayList<TipoServicio>();
		this.t = new TipoServicio();
		this.busqueda = new TipoServicio();
		this.listTipoServicios();
		this.listTipoPagos();
	}

	// m�todos
	
	public String updateTipoServicio(TipoServicio tipoServicio) {
		this.setT(tipoServicio);
		return "tipoServicio.xhtml";
	}

	public void save() {
		try {
			if (t.getIdTipoServicio() == 0) {
				pService.insert(t);
			} else {
				pService.update(t);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller tipoServicio");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getNameServicio().isEmpty()) {
				this.listTipoServicios();
			} else {
				listaTipoServicios = pService.findBy(this.getBusqueda());
			}
		} catch (Exception m) {
			System.out.println("Error al buscar en el controller paciente");
		}
	}

	public String newTipoServicio() {
		this.setT(new TipoServicio());
		this.listTipoPagos();
		return "tipoServicio.xhtml";
	}
	
	public void listTipoPagos() {
		try {
			listaTipoPagos = tService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller tipo pago");
		}
	}

	public void listTipoServicios() {
		try {
			listaTipoServicios = pService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller tipo servicio");
		}
	}

	public void delete(TipoServicio t) {
		try {
			pService.delete(t.getIdTipoServicio());
			this.listTipoServicios();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller tipo servicio");
		}
	}

	// getters and setters

	public TipoServicio getT() {
		return t;
	}

	public void setT(TipoServicio t) {
		this.t = t;
	}

	public List<TipoServicio> getListaTipoServicios() {
		return listaTipoServicios;
	}

	public void setListaTipoServicios(List<TipoServicio> listaTipoServicios) {
		this.listaTipoServicios = listaTipoServicios;
	}

	public List<TipoPago> getListaTipoPagos() {
		return listaTipoPagos;
	}

	public void setListaTipoPagos(List<TipoPago> listaTipoPagos) {
		this.listaTipoPagos = listaTipoPagos;
	}

	public TipoServicio getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(TipoServicio busqueda) {
		this.busqueda = busqueda;
	}
	

}
