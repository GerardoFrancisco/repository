package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IReservaDao;
import pe.edu.upc.entidades.Reserva;

public class ReservaDaoImpl implements IReservaDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(Reserva r) {
		try {
			em.persist(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar reserva");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Reserva> list() {
		List<Reserva> listaReservas = new ArrayList<Reserva>();

		try {
			Query jpql = em.createQuery("from Reserva r");
			listaReservas = (List<Reserva>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar reservas");
		}
		return listaReservas;
	}

	@Transactional
	@Override
	public void delete(int idReserva) {
		try {
			Reserva r = em.find(Reserva.class, idReserva);
			em.remove(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Reserva> findBy(Reserva reserva) {
		List<Reserva> listaReservas = new ArrayList<Reserva>();

		try {
			Query jpql = em.createQuery("from Reserva t where t.paciente.namePaciente like ?1");
			jpql.setParameter(1, "%" + reserva.getPaciente().getNamePaciente() + "%");
			listaReservas = (List<Reserva>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar reserva");
		}
		return listaReservas;
	}
	
	@Transactional
	@Override
	public void update(Reserva r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar reserva");
		}
	}
}
