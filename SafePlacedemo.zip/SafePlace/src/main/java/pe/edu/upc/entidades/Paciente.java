package pe.edu.upc.entidades;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Paciente")
public class Paciente {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idPaciente;

	@Column(name = "birthDatePaciente", nullable = false)
	private Date birthDatePaciente;

	@Column(name = "namePaciente", nullable = false, length = 100)
	private String namePaciente;

	@Column(name = "phonePaciente", nullable = false, length = 100)
	private String phonePaciente;

	public Paciente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Paciente(int idPaciente, Date birthDatePaciente, String namePaciente, String phonePaciente) {
		super();
		this.idPaciente = idPaciente;
		this.birthDatePaciente = birthDatePaciente;
		this.namePaciente = namePaciente;
		this.phonePaciente = phonePaciente;
	}

	public int getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}

	public Date getBirthDatePaciente() {
		return birthDatePaciente;
	}

	public void setBirthDatePaciente(Date birthDatePaciente) {
		this.birthDatePaciente = birthDatePaciente;
	}

	public String getNamePaciente() {
		return namePaciente;
	}

	public void setNamePaciente(String namePaciente) {
		this.namePaciente = namePaciente;
	}

	public String getPhonePaciente() {
		return phonePaciente;
	}

	public void setPhonePaciente(String phonePaciente) {
		this.phonePaciente = phonePaciente;
	}

	@Override
	public int hashCode() {
		return Objects.hash(birthDatePaciente, idPaciente, namePaciente, phonePaciente);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paciente other = (Paciente) obj;
		return Objects.equals(birthDatePaciente, other.birthDatePaciente) && idPaciente == other.idPaciente
				&& Objects.equals(namePaciente, other.namePaciente)
				&& Objects.equals(phonePaciente, other.phonePaciente);
	}

	
}