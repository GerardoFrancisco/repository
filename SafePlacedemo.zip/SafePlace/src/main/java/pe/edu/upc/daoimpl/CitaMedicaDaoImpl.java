package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.ICitaMedicaDao;
import pe.edu.upc.entidades.CitaMedica;

public class CitaMedicaDaoImpl implements ICitaMedicaDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(CitaMedica c) {
		try {
			em.persist(c);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar cita medica");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CitaMedica> list() {
		List<CitaMedica> listaCitaMedicas = new ArrayList<CitaMedica>();

		try {
			Query jpql = em.createQuery("from CitaMedica c");
			listaCitaMedicas = (List<CitaMedica>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar citas medicas");
		}
		return listaCitaMedicas;
	}

	@Transactional
	@Override
	public void delete(int idCitaMedica) {
		try {
			CitaMedica es = em.find(CitaMedica.class, idCitaMedica);
			em.remove(es);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CitaMedica> findBy(CitaMedica citaMedica) {
		List<CitaMedica> listaCitaMedicas = new ArrayList<CitaMedica>();

		try {
			Query jpql = em.createQuery("from CitaMedica t where t.medico.fullNameMedico like ?1");
			jpql.setParameter(1, "%" + citaMedica.getMedico().getFullNameMedico() + "%");
			listaCitaMedicas = (List<CitaMedica>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar citas medicas");
		}
		return listaCitaMedicas;
	}
	
	@Transactional
	@Override
	public void update(CitaMedica r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar citas medicas");
		}
	}
}
