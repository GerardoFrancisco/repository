package pe.edu.upc.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IPacienteDao;
import pe.edu.upc.entidades.Paciente;

public class PacienteDaoImpl implements IPacienteDao {

	@PersistenceContext(unitName = "SafePlace")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(Paciente p) {
		try {
			em.persist(p);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al insertar paciente");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Paciente> list() {
		List<Paciente> listaPacientes = new ArrayList<Paciente>();

		try {
			Query jpql = em.createQuery("from Paciente p");
			listaPacientes = (List<Paciente>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar pacientes");
		}
		return listaPacientes;
	}

	@Transactional
	@Override
	public void delete(int idPaciente) {
		try {
			Paciente p = em.find(Paciente.class, idPaciente);
			em.remove(p);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al eliminar en el dao");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Paciente> findBy(Paciente paciente) {
		List<Paciente> listaPacientes = new ArrayList<Paciente>();

		try {
			Query jpql = em.createQuery("from Paciente t where t.namePaciente like ?1");
			jpql.setParameter(1, "%" + paciente.getNamePaciente() + "%");
			listaPacientes = (List<Paciente>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al listar paciente");
		}
		return listaPacientes;
	}
	
	@Transactional
	@Override
	public void update(Paciente r) {
		try {
			em.merge(r);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Error al modificar paciente");
		}
	}
}
