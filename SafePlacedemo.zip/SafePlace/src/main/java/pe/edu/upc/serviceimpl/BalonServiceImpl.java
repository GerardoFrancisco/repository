package pe.edu.upc.serviceimpl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IBalonDao;
import pe.edu.upc.entidades.Balon;
import pe.edu.upc.service.IBalonService;

@Named
public class BalonServiceImpl implements IBalonService {

	@Inject
	private IBalonDao eDao;

	@Override
	public void insert(Balon e) {
		eDao.insert(e);
	}

	@Override
	public List<Balon> list() {
		// TODO Auto-generated method stub
		return eDao.list();
	}

	@Override
	public void delete(int idBalon) {
		// TODO Auto-generated method stub
		eDao.delete(idBalon);
	}
	
	@Override
	public List<Balon> findBy(Balon balon) {
		// TODO Auto-generated method stub
		return eDao.findBy(balon);
	}

	@Override
	public void update(Balon t) {
		eDao.update(t);
	}

}
