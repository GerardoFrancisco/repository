package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.CitaMedica;

public interface ICitaMedicaDao {

	public void insert(CitaMedica c);

	public List<CitaMedica> list();

	public void delete(int idCitaMedica);

	void update(CitaMedica r);

	List<CitaMedica> findBy(CitaMedica citaMedica);
}
