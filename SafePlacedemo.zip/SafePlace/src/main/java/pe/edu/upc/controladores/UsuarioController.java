package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Usuario;
import pe.edu.upc.service.IUsuarioService;

@Named
@RequestScoped
public class UsuarioController {
	@Inject
	private IUsuarioService uService;

	private Usuario u;
	List<Usuario> listaUsuarios;

	// constructor
	@PostConstruct
	public void init() {
		this.listaUsuarios = new ArrayList<Usuario>();
		this.u = new Usuario();
	}

	// m�todos

	public String newUsuario() {
		this.setU(new Usuario());
		return "usuario.xhtml";
	}

	public String login() {
		try {
			List<Usuario> listaUsuarios = new ArrayList<Usuario>();
			listaUsuarios = this.uService.listByUsernameYContrasenia(this.u.getUsername(), this.u.getContrasenia());
			if (listaUsuarios.isEmpty()) {
				throw new Exception();
			}
			return "panel?faces-redirect=true";
		} catch (Exception ex) {
			return "login?faces-redirect=true";
		}
	}

	// getters and setters
	public Usuario getU() {
		return u;
	}

	public void setU(Usuario u) {
		this.u = u;
	}

	public List<Usuario> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

}
