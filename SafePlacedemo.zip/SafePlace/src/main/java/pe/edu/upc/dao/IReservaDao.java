package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.Reserva;

public interface IReservaDao {

	public void insert(Reserva r);

	public List<Reserva> list();

	public void delete(int idReserva);

	List<Reserva> findBy(Reserva reserva);

	void update(Reserva r);
}
