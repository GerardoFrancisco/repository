package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.Medico;

public interface IMedicoDao {

	public void insert(Medico m);

	public List<Medico> list();

	public void delete(int idMedico);

	List<Medico> findBy(Medico medico);

	void update(Medico r);
}
