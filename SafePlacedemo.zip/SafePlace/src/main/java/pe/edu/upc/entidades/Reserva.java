package pe.edu.upc.entidades;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Reserva")
public class Reserva {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idReserva;

	@Column(name = "fecha", nullable = false)
	private Date fecha;

	@Column(name = "tipoEntrega", nullable = false, length = 100)
	private String tipoEntrega;

	@ManyToOne
	@JoinColumn(name = "idEstablecimiento", nullable = false)
	private Establecimiento establecimiento;
	
	@ManyToOne
	@JoinColumn(name = "idPaciente", nullable = false)
	private Paciente paciente;
	
	public Reserva() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Reserva(int idReserva, Date fecha, String tipoEntrega, Establecimiento establecimiento, Paciente paciente) {
		super();
		this.idReserva = idReserva;
		this.fecha = fecha;
		this.tipoEntrega = tipoEntrega;
		this.establecimiento = establecimiento;
		this.paciente = paciente;
	}

	public int getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(int idReserva) {
		this.idReserva = idReserva;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getTipoEntrega() {
		return tipoEntrega;
	}

	public void setTipoEntrega(String tipoEntrega) {
		this.tipoEntrega = tipoEntrega;
	}

	public Establecimiento getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(Establecimiento establecimiento) {
		this.establecimiento = establecimiento;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	@Override
	public int hashCode() {
		return Objects.hash(establecimiento, fecha, idReserva, paciente, tipoEntrega);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reserva other = (Reserva) obj;
		return Objects.equals(establecimiento, other.establecimiento) && Objects.equals(fecha, other.fecha)
				&& idReserva == other.idReserva && Objects.equals(paciente, other.paciente)
				&& Objects.equals(tipoEntrega, other.tipoEntrega);
	}

	
}