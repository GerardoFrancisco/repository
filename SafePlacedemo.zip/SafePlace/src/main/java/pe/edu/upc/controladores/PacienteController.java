package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Paciente;
import pe.edu.upc.service.IPacienteService;

@Named
@RequestScoped
public class PacienteController {
	@Inject
	private IPacienteService pService;

	private Paciente p;
	private Paciente busqueda;
	List<Paciente> listaPacientes;

	// constructor
	@PostConstruct
	public void init() {
		this.listaPacientes = new ArrayList<Paciente>();
		this.p = new Paciente();
		this.busqueda = new Paciente();
		this.listPacientes();
	}

	// m�todos
	
	public String updatePaciente(Paciente paciente) {
		this.setP(paciente);
		return "paciente.xhtml";
	}

	public void save() {
		try {
			if (p.getIdPaciente() == 0) {
				pService.insert(p);
			} else {
				pService.update(p);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller paciente");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getNamePaciente().isEmpty()) {
				this.listPacientes();
			} else {
				listaPacientes = pService.findBy(this.getBusqueda());
			}
		} catch (Exception m) {
			System.out.println("Error al buscar en el controller paciente");
		}
	}

	public String newPaciente() {
		this.setP(new Paciente());
		return "paciente.xhtml";
	}

	public void listPacientes() {
		try {
			listaPacientes = pService.list();
		} catch (Exception ex) {
			System.out.println("Error al listar en controller paciente");
		}
	}

	public void delete(Paciente p) {
		try {
			pService.delete(p.getIdPaciente());
			this.listPacientes();
		} catch (Exception ex) {
			System.out.println("Error al eliminar en el controller paciente");
		}
	}

	// getters and setters

	public Paciente getP() {
		return p;
	}

	public void setP(Paciente p) {
		this.p = p;
	}

	public List<Paciente> getListaPacientes() {
		return listaPacientes;
	}

	public void setListaPacientes(List<Paciente> listaPacientes) {
		this.listaPacientes = listaPacientes;
	}

	public Paciente getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(Paciente busqueda) {
		this.busqueda = busqueda;
	}

	
}
