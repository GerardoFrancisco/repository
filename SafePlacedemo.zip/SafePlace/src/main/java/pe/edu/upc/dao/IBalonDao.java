package pe.edu.upc.dao;

import java.util.List;

import pe.edu.upc.entidades.Balon;

public interface IBalonDao {

	public void insert(Balon b);

	public List<Balon> list();

	public void delete(int idBalon);

	List<Balon> findBy(Balon balon);

	void update(Balon r);
}
