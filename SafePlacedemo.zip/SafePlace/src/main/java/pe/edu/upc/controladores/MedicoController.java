package pe.edu.upc.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entidades.Medico;
import pe.edu.upc.service.IMedicoService;


@Named
@RequestScoped
public class MedicoController {
	@Inject
	private IMedicoService mService;

	private Medico m;
	private Medico busqueda;
	
	List<Medico> listaMedicos;

	// constructor
	@PostConstruct
	public void init() {
		this.listaMedicos = new ArrayList<Medico>();
		this.m = new Medico();
		this.busqueda = new Medico();
		this.list();
	}

	public String updateMedico(Medico medico) {
		this.setM(medico);
		return "medico.xhtml";
	}

	public void save() {
		try {
			if (m.getIdMedico() == 0) {
				mService.insert(m);
			} else {
				mService.update(m);
			}
		} catch (Exception ex) {
			System.out.println("Error al guardar en el controller medico");
		}
	}
	
	public void clean() {
		this.init();
	}

	public void findBy() {
		try {
			if (busqueda.getFullNameMedico().isEmpty()) {
				this.list();
			} else {
				listaMedicos = mService.findBy(this.getBusqueda());
			}
		} catch (Exception m) {
			System.out.println("Error al buscar en el controller medico");
		}
	}

	public String newMedico() {

		this.setM(new Medico());
		return "medico.xhtml";
	}

	public void list() {
		try {
			listaMedicos = mService.list();
		} catch (Exception m) {
			System.out.println("Error al listar en controller Medico");
		}
	}

	public void delete(Medico med) {
		try {
			mService.delete(med.getIdMedico());
			this.list();
		} catch (Exception m) {
			System.out.println("Error al eliminar en elcontroller Medico");
		}
	}

	// getters and setters
	public Medico getM() {
		return m;
	}

	public List<Medico> getListaMedicos() {
		return listaMedicos;
	}

	public void setListaMedicos(List<Medico> listaMedicos) {
		this.listaMedicos = listaMedicos;
	}

	public Medico getBusqueda() {
		return busqueda;
	}

	public void setBusqueda(Medico busqueda) {
		this.busqueda = busqueda;
	}

	public void setM(Medico m) {
		this.m = m;
	}
	
	

}
