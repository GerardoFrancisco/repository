package pe.edu.upc.entidades;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Medico")
public class Medico {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idMedico;

	@Column(name = "fullNameMedico", nullable = false, length = 45)
	private String fullNameMedico;

	@Column(name = "birthDateMedico", nullable = false)
	private Date birthDateMedico;

	@Column(name = "adressMedico", nullable = false, length = 35)
	private String adressMedico;

	@Column(name = "emailMedico", nullable = false, length = 35)
	private String emailMedico;

	@Column(name = "phoneMedico", nullable = false, length = 15)
	private String phoneMedico;

	public Medico() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Medico(int idMedico, String fullNameMedico, Date birthDateMedico, String adressMedico, String emailMedico,
			String phoneMedico) {
		super();
		this.idMedico = idMedico;
		this.fullNameMedico = fullNameMedico;
		this.birthDateMedico = birthDateMedico;
		this.adressMedico = adressMedico;
		this.emailMedico = emailMedico;
		this.phoneMedico = phoneMedico;
	}

	public int getIdMedico() {
		return idMedico;
	}

	public void setIdMedico(int idMedico) {
		this.idMedico = idMedico;
	}

	public String getFullNameMedico() {
		return fullNameMedico;
	}

	public void setFullNameMedico(String fullNameMedico) {
		this.fullNameMedico = fullNameMedico;
	}

	public Date getBirthDateMedico() {
		return birthDateMedico;
	}

	public void setBirthDateMedico(Date birthDateMedico) {
		this.birthDateMedico = birthDateMedico;
	}

	public String getAdressMedico() {
		return adressMedico;
	}

	public void setAdressMedico(String adressMedico) {
		this.adressMedico = adressMedico;
	}

	public String getEmailMedico() {
		return emailMedico;
	}

	public void setEmailMedico(String emailMedico) {
		this.emailMedico = emailMedico;
	}

	public String getPhoneMedico() {
		return phoneMedico;
	}

	public void setPhoneMedico(String phoneMedico) {
		this.phoneMedico = phoneMedico;
	}

	@Override
	public int hashCode() {
		return Objects.hash(adressMedico, birthDateMedico, emailMedico, fullNameMedico, idMedico, phoneMedico);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Medico other = (Medico) obj;
		return Objects.equals(adressMedico, other.adressMedico)
				&& Objects.equals(birthDateMedico, other.birthDateMedico)
				&& Objects.equals(emailMedico, other.emailMedico)
				&& Objects.equals(fullNameMedico, other.fullNameMedico) && idMedico == other.idMedico
				&& Objects.equals(phoneMedico, other.phoneMedico);
	}

}
