package pe.edu.upc.demo.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.demo.entities.Balon;
import pe.edu.upc.demo.repositories.IBalonRepository;
import pe.edu.upc.demo.serviceinterface.IBalonService;

@Service
public class BalonServiceImpl implements IBalonService {

	@Autowired
	private IBalonRepository balonRepository;
	
	
	@Override
	public void insert(Balon balon) {
		// TODO Auto-generated method stub
		balonRepository.save(balon);
	}

	@Override
	public List<Balon> list() {
		// TODO Auto-generated method stub
		return balonRepository.findAll();
	}

	@Override
	public void delete(int idBalon) {
		// TODO Auto-generated method stub
		balonRepository.deleteById(idBalon);
	}

	@Override
	public Optional<Balon> listId(int idBalon) {
		// TODO Auto-generated method stub
		return balonRepository.findById(idBalon);
	}

	@Override
	public void updateBalon(Balon balon) {
		
		balonRepository.save(balon);
	}

}
