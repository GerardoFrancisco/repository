package pe.edu.upc.demo.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.Medico;

public interface IMedicoService {
	public void insert(Medico medico);

	public List<Medico> list();

	public void delete(int idMedico);

	Optional<Medico> listId(int idMedico);
	
	public void updateMedico (Medico medico);
}
