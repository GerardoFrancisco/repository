package pe.edu.upc.demo.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.Establecimiento;

public interface IEstablecimientoService {
	public void insert(Establecimiento establecimiento);

	public List<Establecimiento> list();

	public void delete(int idEstablecimiento);

	Optional<Establecimiento> listId(int idEstablecimiento);

	public void updateEstablecimiento(Establecimiento establecimiento);
}
