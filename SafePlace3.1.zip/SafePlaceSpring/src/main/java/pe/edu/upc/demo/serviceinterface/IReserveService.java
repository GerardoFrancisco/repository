package pe.edu.upc.demo.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.Reserve;

public interface IReserveService {

	public void insert(Reserve reserve);

	public List<Reserve> list();

	public void delete(int idPerson);

	Optional<Reserve> listId(int idReserve);

	public void update(Reserve reserve);
}
