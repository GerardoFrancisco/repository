package pe.edu.upc.demo.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.demo.entities.TipoPago;
import pe.edu.upc.demo.repositories.ITipoPagoRepository;
import pe.edu.upc.demo.serviceinterface.ITipoPagoService;

@Service
public class TipoPagoServiceImpl implements ITipoPagoService {

	@Autowired
	private ITipoPagoRepository tpagoRepository;
	
	@Override
	public void insert(TipoPago tipopago) {
		// TODO Auto-generated method stub
		tpagoRepository.save(tipopago);
	}

	@Override
	public List<TipoPago> list() {
		// TODO Auto-generated method stub
		return tpagoRepository.findAll();
	}

	@Override
	public void delete(int idTPago) {
		// TODO Auto-generated method stub
		tpagoRepository.deleteById(idTPago);
	}

	@Override
	public Optional<TipoPago> listId(int idTPago) {
		// TODO Auto-generated method stub
		return tpagoRepository.findById(idTPago);
	}

	@Override
	public void updateTipoPago(TipoPago tipopago) {
		
		tpagoRepository.save(tipopago);
	}

}
