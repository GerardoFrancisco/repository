package pe.edu.upc.demo.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity 
@Table(name = "Medico")
public class Medico {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idMedico;

	@Column(name = "Nombre", nullable = false, length = 45)
	private String Nombre;
	
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "FechadeNacimiento", nullable = false)
	private Date FechadeNacimiento;
	
	@Column(name = "Direccion", nullable =false , length = 35)
	private String Direccion;
	
	@Column(name = "Correo", nullable =false , length = 35)
	private String Correo;
	
	@Column(name = "Celular", nullable = false, length = 9)
	private String Celular;
	
	public Medico() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Medico(int idMedico, String Nombre, Date FechadeNacimiento, String Direccion, String Correo ,String Celular) {
		super();
		this.idMedico = idMedico;
		this.Nombre = Nombre;
		this.FechadeNacimiento = FechadeNacimiento;
		this.Direccion = Direccion ;
		this.Correo = Correo; 
		this.Celular = Celular;
	}
	
	public int getIdMedico() {
		return idMedico;
	}

	public void setIdMedico(int idMedico) {
		this.idMedico = idMedico;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String Nombre) {
		this.Nombre = Nombre;
	}

	public Date getFechadeNacimiento() {
		return FechadeNacimiento;
	}

	public void setFechadeNacimiento(Date FechadeNacimiento) {
		this.FechadeNacimiento = FechadeNacimiento;
	}

	public String getDireccion() {
		return Direccion;
	}

	public void setDireccion(String Direccion) {
		this.Direccion = Direccion;
	}
	public String getCorreo() {
		return Correo;
	}

	public void setCorreo(String Correo) {
		this.Correo = Correo;
	}

	public String getCelular() {
		return Celular;
	}

	public void setCelular(String Celular) {
		this.Celular = Celular;
	}

}
	