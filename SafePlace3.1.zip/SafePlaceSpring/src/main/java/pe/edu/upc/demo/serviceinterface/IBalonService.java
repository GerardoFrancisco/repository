package pe.edu.upc.demo.serviceinterface;
import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.Balon;


public interface IBalonService {

	public void insert(Balon balon);

	public List<Balon> list();
	
	public void delete(int idBalon);
	Optional<Balon>listId(int idBalon);

	public void updateBalon(Balon balon);
	
}
