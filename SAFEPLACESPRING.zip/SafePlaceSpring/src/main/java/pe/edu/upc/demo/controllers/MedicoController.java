package pe.edu.upc.demo.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.demo.entities.Medico;
import pe.edu.upc.demo.serviceinterface.MedicoService;

@Controller
@RequestMapping("/medicos")
public class MedicoController {
	@Autowired
	private MedicoService MedService;

	@GetMapping("/nuevoMedico")
	public String newMedico(Model model) {
		model.addAttribute("p", new Medico());
		return "medico/frmRegistroMedico";
	}

	@PostMapping("/guardarMedico")
	public String saveMedico(@Valid Medico med, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "medico/frmRegistroMedico";
		} else {
			MedService.insert(med);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			return "redirect:/medicos/nuevoMedico";
		}

	}
	@GetMapping("/listarMedico")
	public String listMedico(Model model) {
		try {
			model.addAttribute("listaMedico", MedService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/medico/frmListaMedico";
	}

	@RequestMapping("/eliminarMedico")
	public String deleteMedico(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				MedService.delete(id);
				model.put("listaMedico", MedService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "medico/frmListaMedicos";
	}
	
	@RequestMapping("/irmodificarMedico/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Medico> objMed = MedService.listId(id);
		model.addAttribute("Medicos", objMed.get());
		return "medico/frmActualizaMedico";
	}


	
	
	
}
