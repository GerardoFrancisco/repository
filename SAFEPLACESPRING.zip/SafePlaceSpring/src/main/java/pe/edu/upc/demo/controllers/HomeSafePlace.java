package pe.edu.upc.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class HomeSafePlace {
	
	@RequestMapping("/bienvenido")
	public String home() {
		
		return"paciente/HomeSafeplace";
	}

}
