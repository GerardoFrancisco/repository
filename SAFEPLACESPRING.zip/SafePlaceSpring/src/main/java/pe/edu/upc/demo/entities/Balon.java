package pe.edu.upc.demo.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name="Balon")
public class Balon {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idBalon;
	
	@Column(name = "toxigeno", nullable = false, length = 44)
	private String toxigeno;
	
	@Column(name = "capacidad", nullable = false, length = 45)
	private double capacidad;
	

	@Column(name = "peso", nullable = false, length = 45)
	private double peso;
	
	@Column(name = "precio", nullable = false, length = 45)
	private double precio;

	@ManyToOne
	@JoinColumn(name = "idEstablecimiento")
	private Establecimiento establecimiento;
	
	public Balon() {
		super();
		//TODO Auto-generated constructor stub
	}

	public Balon(int idBalon, String toxigeno, double capacidad, double peso, double precio,
			Establecimiento establecimiento) {
		super();
		this.idBalon = idBalon;
		this.toxigeno = toxigeno;
		this.capacidad = capacidad;
		this.peso = peso;
		this.precio = precio;
		this.establecimiento = establecimiento;
	}

	public int getIdBalon() {
		return idBalon;
	}

	public void setIdBalon(int idBalon) {
		this.idBalon = idBalon;
	}

	public String getToxigeno() {
		return toxigeno;
	}

	public void setToxigeno(String toxigeno) {
		this.toxigeno = toxigeno;
	}

	public double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Establecimiento getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(Establecimiento establecimiento) {
		this.establecimiento = establecimiento;
	}

}