package pe.edu.upc.demo.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.demo.entities.Reserve;
import pe.edu.upc.demo.serviceinterface.IReserveService;

@Controller
@RequestMapping("/reservas")
public class ReserveController {

	@Autowired
	private IReserveService resService;

	@GetMapping("/nuevo")
	public String newReserve(Model model) {
		model.addAttribute("r", new Reserve());
		return "reserva/frmRegistroReserva";
	}

	@PostMapping("/guardar")
	public String saveReserve(@Valid Reserve res, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "reserva/frmRegistroReserva";
		} else {
			resService.insert(res);
			model.addAttribute("mensaje", "Se registró correctamente");
			return "redirect:/reservas/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listReserve(Model model) {
		try {
			model.addAttribute("listaReservas", resService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/reserva/frmListaReserva";
	}

	@RequestMapping("/eliminar")
	public String deleteReserve(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {

			if (id != null && id > 0) {
				resService.delete(id);
				model.put("listaReservas", resService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}

		return "reserva/frmListaReserva";
	}

	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {

		Optional<Reserve> objRes = resService.listId(id);
		model.addAttribute("rese", objRes.get());
		return "/reserva/frmActualizaReserva";
	}

	@RequestMapping("/modificar")
	public String updatePerson(Reserve re) {
		resService.update(re);
		return "redirect:/reservas/listar";
	}
}
