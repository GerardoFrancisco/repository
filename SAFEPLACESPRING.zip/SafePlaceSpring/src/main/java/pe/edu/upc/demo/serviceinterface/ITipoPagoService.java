package pe.edu.upc.demo.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.TipoPago;

public interface ITipoPagoService {
	public void insert(TipoPago tipopago);

	public List<TipoPago> list();
	
	public void delete(int idTPago);
	Optional<TipoPago>listId(int idTPago);
}
