package pe.edu.upc.demo.serviceimplements;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.demo.entities.Establecimiento;
import pe.edu.upc.demo.repositories.IEstablecimientoRepository;
import pe.edu.upc.demo.serviceinterface.IEstablecimientoService;

@Service
public class EstablecimientoServiceImpl implements IEstablecimientoService {

	@Autowired
	private IEstablecimientoRepository establecimientoRepository;
	
	@Override
	public void insert(Establecimiento establecimiento) {
		// TODO Auto-generated method stub
		establecimientoRepository.save(establecimiento);
	}

	@Override
	public List<Establecimiento> list() {
		// TODO Auto-generated method stub
		return establecimientoRepository.findAll();
	}

	@Override
	public void delete(int idEstablecimiento) {
		// TODO Auto-generated method stub
		establecimientoRepository.deleteById(idEstablecimiento);
	}

	@Override
	public Optional<Establecimiento> listId(int idEstablecimiento) {
		// TODO Auto-generated method stub
		return establecimientoRepository.findById(idEstablecimiento);
	}

}
